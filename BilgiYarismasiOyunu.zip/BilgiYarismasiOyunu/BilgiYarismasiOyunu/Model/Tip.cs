﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BilgiYarismasiOyunu.Model
{
    internal class SoruTipleri
    {
        public int TipID { get; set; }
        public string Tip { get; set; }
    }
}
